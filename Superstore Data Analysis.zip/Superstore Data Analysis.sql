# SQL Assignment No. 1


create database Superstores;


/*1. Write a query to display the Customer_Name and Customer Segment using alias 
name “Customer Name", "Customer Segment" from table Cust_dimen. */

select
 Customer_Name AS 'Customer Name', 
 Customer_Segment AS 'Customer Segment'
from cust_dimen;
 

 /*2. Write a query to find all the details of the customer from the table cust_dimen 
order by desc.*/


select * 
from cust_dimen
order by Customer_Name desc;


/*3.. Write a query to get the Order ID, Order date from table orders_dimen where 
‘Order Priority’ is high.*/

select order_id, order_date
from orders_dimen 
where order_priority='HIGH';


/*4. Find the total and the average sales (display total_sales and avg_sales) */

select
    sum(sales)  AS total_sales,
    avg(sales) AS avg_sales
from market_fact;


/*5. Write a query to get the maximum and minimum sales from maket_fact table.*/

select
    min(sales)  AS min_sales,
   max(sales) AS max_sales
from market_fact;


/*6. Display the number of customers in each region in decreasing order of 
no_of_customers. The result should contain columns Region, no_of_customers.
*/

select
   region,
   count(*) as no_of_customers
from cust_dimen
group by region
order by region;
   
   
/*7. Find the region having maximum customers (display the region name and 
max(no_of_customers)*/

select region , count(*) AS no_of_customer
from cust_dimen
group by Region
order by no_of_customer desc
limit 1;


/*8. Find all the customers from Atlantic region who have ever purchased ‘TABLES’ 
and the number of tables purchased (display the customer name, no_of_tables 
purchased)*/

select c.Customer_name, count(m.Prod_id)
from cust_dimen c 
	join
     market_fact m
     on m.Cust_id = c.Cust_id 
	join
     prod_dimen p 
     on p.Prod_id = m.Prod_id 
where c.Region = 'ATLANTIC' and p.Product_Sub_Category = 'TABlES'
group by c.Customer_name;


/*9.Find all the customers from Ontario province who own Small Business. (display 
the customer name, no of small business owners*/
 
select 
   customer_name,
   count(customer_segment) AS  'no of small business owners'
from cust_dimen
where customer_segment="SMALL BUSINESS"
group by customer_name;


/*10. Find the number and id of products sold in decreasing order of products sold 
(display product id, no_of_products sold) */
 
select 
   prod_id AS 'product id',
   sum(order_Quantity) AS 'no_of_products sold'
from market_fact
group by prod_id
order by sum(order_Quantity)  desc;


/*11. Display product Id and product sub category whose produt category belongs to 
Furniture and Technlogy. The result should contain columns product id, product 
sub category.
*/
 
select 
   prod_id AS 'product id',
   product_sub_category As 'product sub category'
from prod_dimen 
where product_category="Furniture" or product_category="Technology";   


/*12. Display the product categories in descending order of profits (display the product 
category wise profits i.e. product_category, profits)?
*/
 
select 
    p.product_category AS product_category,
    m.profit As profits
from market_fact as m 
left join 
prod_dimen as p 
	on m.prod_id = p.prod_id
order by m.profit desc; 


/*13. Display the product category, product sub-category and the profit within each 
subcategory in three columns. */

select p.Product_Category as "Product Category", 
	p.Product_Sub_Category as "Product Sub Category",
	round(sum(m.Profit), 2) as "Total Profits"
from market_fact m 
	join 
	prod_dimen p 
  on m.Prod_id = p.Prod_id
group by p.Product_Sub_Category
Order by p.Product_Category;


/*14. Display the order date, order quantity and the sales for the order.*/
 
 select 
    o.Order_date,
    m.order_quantity,
    m.sales
from 
orders_dimen as o
left join
market_fact as m 
  on o.ord_id=m.ord_id;


/*15. Display the names of the customers whose name contains the 
 i) Second letter as ‘R’
 ii) Fourth letter as ‘D'*/
 
select 
   customer_name 
from cust_dimen
where customer_name  LIke "_R%" and customer_name  LIke "___D%";


/*16. Write a SQL query to to make a list with Cust_Id, Sales, Customer Name and 
their region where sales are between 1000 and 5000.
*/
 
select 
    c.cust_id,
    m.sales,
    c.customer_name,
    c.region
from cust_dimen As c
join
market_fact as m 
on c.cust_id = m.cust_id
where m.sales between 1000 and 5000;


/*17. Write a SQL query to find the 3rd highest sales.*/
 
select 
	sales 
from market_fact 
order by sales desc limit 1 offset 2; 


/*18. Where is the least profitable product subcategory shipped the most? 
#For the least profitable product sub-category, display the region-wise 
#no_of_shipments and the profit made in each region in decreasing order of profits (i.e. region, 
no_of_shipments, profit_in_each_region)
 → Note: You can hardcode the name of the least profitable product subcategory*/
 
 select 
    c.Region as "Region",
    count(m.Ship_id) as "No of Shipments", 
	round(sum(m.Profit),2) as "Profit in each region"
from market_fact m 
		join cust_dimen c on m.Cust_id = c.Cust_id
        join prod_dimen p on m.Prod_id = p.Prod_id
Where Product_Sub_Category = (
				Select
                    p.Product_Sub_Category 
				from market_fact m 
				join prod_dimen p on m.Prod_id = p.Prod_id
				group by Product_Sub_Category
				order by sum(m.Profit)
				LIMIT 1) 
group by c.Region
order by sum(m.Profit);

# END